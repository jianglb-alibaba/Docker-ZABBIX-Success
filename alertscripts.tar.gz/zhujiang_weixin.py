#!/usr/bin/env python
# -*- coding:utf-8 -*-
#File http_post.py
import urllib
import urllib2
import os
import json
import sys
import re
import time
import httplib
reload(sys)
sys.setdefaultencoding( "utf-8" )

def http_post(title,touser,content):
	url="http://10.1.18.40/message/push?"
	values={'title':'helloYes','touser':'121343','toparty':'','push_type':'1','msg_type':'1','msg_level':'1','content':'hello','timeout':'15'}

	data = json.dumps(values,sort_keys=True,indent=2)
	#data = json.dumps(values,sort_keys=True)
	#data=json.dumps({
	#	'title':title,
	#	'touser':touser,
	#	'toparty':"",
	#	'push_type':"1",
	#	'msg_type':"1",
	#	'msg_level':"1",
	#	'content':content,
	#	'timeout':"15"
	#},ensure_ascii=False)
	#})
	#data=urllib.urlencode(values)
	print data
	req=urllib2.Request(url,data)
	response = urllib2.urlopen(req)
	result=response.read()
	#print result
	return result

def check_space(str):
	newstr=''
	for i in str:
		strinfo = re.compile(' ')
		newstr=strinfo.sub('%20',str)
	#print newstr
	return newstr

def strip_str(str):
	return str.strip()

def huanhang(str):
	newstr = ''
	for i in str:
		#strinfo = re.compile(r"as")
		strinfo = re.compile(r"\\r")
		newstr=strinfo.sub('%0d%0a',str)
	print newstr
	return newstr


#None data
def http_get(touser,title,content):
#def http_get():
	#url = "http://10.1.18.40/message/push?title=123&touser=121343&toparty=&push_type=1&msg_type=1&msg_level=1&content=hello&timeout=15"
	url = "http://10.1.18.40/message/push?title="+title+"&touser="+touser+"&toparty=&push_type=1&msg_type=1&msg_level=1&content="+content+"&timeout=15"


	conn = httplib.HTTPConnection("10.1.18.40")
	conn.request(method="GET",url=url) 

	response = conn.getresponse()
	res= response.read()
	#print res
	return res
	#data=json.dumps({"code":"0","msg":"�ɹ�����"})
	#print data
	#return  data
#main
#resp=http_get()
#data={'title':'sys.argv[2]','touser':'sys.argv[3]','toparty':'','push_type':'1','msg_type':'1','msg_level':'1','content':'sys.argv[4]','timeout':'15'}
#data={'title':'123','touser':'121343','toparty':'','push_type':'1','msg_type':'1','msg_level':'1','content':'test','timeout':'15'}
#resp = http_post(sys.argv[1],data)

mytouser=sys.argv[1]
mytitle=sys.argv[2]
#mytitle=sys.argv[2].decode('utf-8').encode('gbk')
mycontent=sys.argv[3]
#mycontent=sys.argv[3].decode('utf-8').encode('gbk')
nonecontent = ''
if mytitle.strip()=='' or  mytouser.strip()==''  or  mycontent.strip()=='' :
	nonecontent= "the parameters has none"
	otherStyleTime=time.strftime("%Y-%m-%d %H:%M:%S")
	path=sys.path[0]
#path=os.getcwd()
	f=open(path +'/zhujiang.log','a+')
	f.write("ERROR: "+otherStyleTime)
	f.write(nonecontent + '\n')
	f.close()
	exit


else:
	#print "my title: "+check_space(mytitle)
	#print "my content: "+check_space(mycontent)
	#print "my touser: "+strip_str(mytouser)
	#print  huanhang(mycontent)
	
	http_get(strip_str(mytouser),check_space(mytitle),huanhang(check_space(mycontent)))
	#http_get(mytouser,mytitle,mycontent)
	
	otherStyleTime=time.strftime("%Y-%m-%d %H:%M:%S")
	path=sys.path[0]
	path=os.getcwd()
	f=open(path +'/zhujiang.log','a+')
	f.write(otherStyleTime+'\n')
	f.write('	title : ' +mytitle +'\n')
	f.write('	content : '+mycontent+'\n')
	f.write('	Committed Successlly!  ' +'\n')
	f.close()

	


#resp=http_get()
#resp=http_post(sys.argv[1],sys.argv[2],sys.argv[3])


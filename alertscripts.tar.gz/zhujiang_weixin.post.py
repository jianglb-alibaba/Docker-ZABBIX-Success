#!/usr/bin/env python
# -*- coding:utf-8 -*-
#File http_post.py
import urllib
import urllib2
import json
import sys
import re
import time
import httplib
reload(sys)
sys.setdefaultencoding( "utf-8" )

#def http_post(title,touser,content):
def http_post():
	url="http://10.1.18.40/message/push"
	headers ={"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
	values={'title':'helloYes','touser':'121343','toparty':'','push_type':'1','msg_type':'1','msg_level':'1','content':'hello','timeout':'15'}
	data=urllib.urlencode(values)
	req=urllib2.Request(url,data,headers)
	response = None

	#data = json.dumps(values,sort_keys=True,indent=2)
	#data = json.dumps(values,sort_keys=True)
	#values=json.dumps({
	#	'title':title,
	#	'touser':touser,
	#	'toparty':"",
	#	'push_type':"1",
	#	'msg_type':"1",
	#	'msg_level':"1",
	#	'content':content,
	#	'timeout':"15"
	#	},ensure_ascii=False)
	
        try:
		#headers ={"Content-type": "application/x-www-form-urlencoded","Accept": "text/plain"}
		#httpClient = httplib.HTTPConnection("http://10.1.18.40",80,timeout=10)
		#httpClient.request("POST","/message/push/test?",data,headers)
		#response = httpClient.getresponse()
		#req=urllib2.Request(url,data)
		response = urllib2.urlopen(req)

        	#conn = httplib.HTTPConnection("10.1.18.40")
     	   	#conn.request.post("http://10.1.18.40/message/push',data=data) 
        	#response = conn.getresponse()
        	#res= response.read()
		status=response.getcode()
		print status
		print response.read()
	except urllib2.HTTPError, e:
		#print e.code


		print response.status
		#print response.reason
		#print response.read()
		#print response.getheaders()
		
	except  Exception , e:
		print e
	f=response.read().decode("utf8")
	outfile = open("/tmp/response.log","w")
	print >> outfile , "%s"   %( f)
	info = response.info()
	print info

def check_space(str):
	newstr=''
	for i in str:
		strinfo = re.compile(' ')
		newstr=strinfo.sub('%20',str)
	#print newstr
	return newstr

def strip_str(str):
	return str.strip()

def huanhang(str):
	newstr = ''
	for i in str:
		#strinfo = re.compile(r"as")
		strinfo = re.compile(r"\\r")
		newstr=strinfo.sub('%0d%0a',str)
	print newstr
	return newstr




#resp=http_post(sys.argv[1],sys.argv[2],sys.argv[3])
resp=http_post()


#!/bin/bash
ip=$1
active_time=`date +%Y%m%d%H%M%S`
/bin/traceroute $ip > /usr/local/zabbix/share/zabbix/alertscripts/${active_time}-$ip.txt 2>&1

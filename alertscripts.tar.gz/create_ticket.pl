#!/usr/bin/perl
use strict;
use warnings;
use SOAP::Lite;
use Data::Dumper;

if(!$ARGV[0])
	{die 'Please input the first paramter'}
elsif(!$ARGV[1])
	{die 'Please input the second paramter'}
elsif(!$ARGV[2])
	{die 'Please input the third paramter'}

#print "the first parameter is: $ARGV[0]\n";
#print "the first parameter is: $ARGV[1]\n";
#print "the first parameter is: $ARGV[2]\n";

my $first=$ARGV[0];
my $subject=$ARGV[1];
my $body=$ARGV[2];

my $soap = SOAP::Lite->uri('http://www.otrs.org/TicketConnector/')->proxy('http://10.1.0.38/otrs/nph-genericinterface.pl/Webservice/GenericTicketConnector'); 

#my $XMLData = "<UserLogin>superadmin</UserLogin><Password>admin</Password><Ticket><Title>zabbix worning</Title><CustomerUser>piter_shu</CustomerUser><QueueID>3</QueueID><State>new</State><Priority>5 very high</Priority></Ticket><Article><Subject>$subject</Subject><Body>$body</Body><ContentType>text/plain; charset=utf8</ContentType></Article>";


my $XMLData = "<UserLogin>zabbix_desk</UserLogin><Password>123456</Password><Ticket><Title>$subject</Title><CustomerUser>zabbix</CustomerUser><Queue>zabbix</Queue><State>new</State><Priority>5 very high</Priority><Type>Incident</Type></Ticket><Article><Subject>$subject</Subject><Body>$body</Body><ContentType>text/plain; charset=utf8</ContentType></Article>";

my $SOAPData = SOAP::Data->type( 'xml' => $XMLData );
#print Dumper($soap->TicketCreate($SOAPData)->result);
$soap->TicketCreate($SOAPData);

